import java.util.Scanner;
import java.time.*;

public class employee{

    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        String name;
        int dob,mob,birth_year;
        float tax,annual_salary,monthly_salary;
        System.out.println("Enter your name:");
        name=sc.nextLine();
        System.out.println("Enter your date of birth:");
        dob=sc.nextInt();
        System.out.println("Enter your month of birth:");
        mob=sc.nextInt();
        System.out.println("Enter your year of birth:");
        birth_year=sc.nextInt();
        System.out.println("Enter your monthly salary:");
        monthly_salary=sc.nextFloat();

        annual_salary=monthly_salary*12;
        
        if(annual_salary>=500000){
            tax= (20*annual_salary)/100;
        }
        else if(annual_salary>=400000 && annual_salary<500000){
            tax=(15*annual_salary)/100;
        }
        else if(annual_salary>=300000 && annual_salary<400000){
            tax=(10*annual_salary)/100;
        }
        else if(annual_salary>=200000 && annual_salary<300000){
            tax=(5*annual_salary)/100;
        }
        else{
            tax=0;
        }

        LocalDate pdate = LocalDate.of(birth_year,mob, dob);
        LocalDate now = LocalDate.now();
        Period diff = Period.between(pdate, now);
        

        System.out.println("The name is:"+name);
        System.out.printf("Your age is  %d years, %d months and %d days old.\n",
                    diff.getYears(), diff.getMonths(), diff.getDays());
        System.out.println("The annual salary is:"+annual_salary);
        System.out.println("The tax is:"+tax);            

    }
}