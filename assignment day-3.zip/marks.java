import java.util.Scanner;
public class marks {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        float num1,num2,num3,num4,num5,percentage;
        System.out.println("Enter your first subject marks: ");
        num1=sc.nextFloat();
        System.out.println("Enter your second subject marks: ");
        num2=sc.nextFloat();
        System.out.println("Enter your third subject marks: ");
        num3=sc.nextFloat();
        System.out.println("Enter your fourth subject marks: ");
        num4=sc.nextFloat();
        System.out.println("Enter your fifth subject marks: ");
        num5=sc.nextFloat();

        percentage=((num1+num2+num3+num4+num5)/500)*100;

        if(percentage>=90){
            System.out.println("Your percentage is:"+percentage+" and your grade is A+");
        }
        else if(percentage>=80 && percentage<90){
            System.out.println("Your percentage is:"+percentage+" and your grade is A");
        }
        else if(percentage>=70 && percentage<80){
            System.out.println("Your percentage is:"+percentage+" and your grade is B+");
        }
        else if(percentage>=60 && percentage<70){
            System.out.println("Your percentage is:"+percentage+" and your grade is B");
        }
        else{
            System.out.println("Your percentage is:"+percentage+" and your grade is C");
        }
    }
}
