package com.employee;

public class Main {

    public static void main(String[] args) {
			employee e=new employee();
			employee e1=new employee();
			e.display();
			e1.display();

		}
}
