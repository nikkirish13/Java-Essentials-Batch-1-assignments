package com.employee;
import java.util.*;
public class employee {
    String name="Nitika";
    int age=23;
    String city="Agra";

    public void display(){
        System.out.println("The name is: "+name);
        System.out.println("The age is: "+age);
        System.out.println("The city is: "+city);
    }

}
