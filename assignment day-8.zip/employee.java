import java.util.Scanner;
import java.util.Scanner.*;
public class employee {
    public String name;
    public double salary;
    public int age;
    public String designation;

    Scanner sc=new Scanner(System.in);
    public void getDetails(){
        System.out.println("Enter your name:");
        name=sc.next();
        System.out.println("Enter your age:");
        age=sc.nextInt();
        System.out.println("Enter your salary:");
        salary=sc.nextDouble();
        System.out.println("Enter your designation:");
        designation=sc.next();
    }
    public void displayDetails(){
        System.out.println("Name:"+name);
        System.out.println("Age:"+age);
        System.out.println("Salary:"+salary);
        System.out.println("Designation:"+designation);
    }

}
