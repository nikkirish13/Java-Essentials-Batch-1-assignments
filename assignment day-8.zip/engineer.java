import java.util.Scanner;

public class engineer extends employee {
    Scanner sc=new Scanner(System.in);
    public int projects;
    public void getProjects(){
        System.out.println("Enter the number of projects worked on");
        projects=sc.nextInt();
    }
    public void displayProjects(){
        System.out.println(projects);
    }
}
