public class Main {
    public static void main(String[] args){

    doctor[] d=new doctor[3];
    for(int i=0;i<3;i++){
        d[i]=new doctor();
        d[i].getDetails();
        d[i].getPatients();

    }
    for(int i=0;i<3;i++){
        d[i].displayDetails();
        d[i].displayPatients();
    }

    engineer[] e=new engineer[3];
    for(int i=0;i<3;i++){
            e[i]=new engineer();
            e[i].getDetails();
            e[i].getProjects();
        }
    for(int i=0;i<3;i++){
        e[i].displayDetails();
        e[i].displayProjects();
        }

        pilot[] p=new pilot[3];
        for(int i=0;i<3;i++){
            p[i]=new pilot();
            p[i].getDetails();
            p[i].getFlights();
        }
        for(int i=0;i<3;i++){
            p[i].displayDetails();
            p[i].displayFlights();
        }


    }

}
