import java.util.Scanner;
public class doctor extends employee{
    public int no_of_patients;
    Scanner sc=new Scanner(System.in);
    public void getPatients(){
        System.out.println("Enter the number of patients attended daily");
        no_of_patients=sc.nextInt();
    }
    public void displayPatients(){
        System.out.println(no_of_patients);
    }
}
