import java.util.Scanner;

public class pilot extends employee {
    Scanner sc=new Scanner(System.in);
    public int no_of_flights;
    public void getFlights(){
        System.out.println("Enter the number of flights you have flew");
        no_of_flights=sc.nextInt();
    }
    public void displayFlights(){
        System.out.println(no_of_flights);
    }
}
