import java.util.Scanner;
 
public class avenger{
    Scanner sc=new Scanner(System.in);
    String name,power,weapon,planet;
    int age;


        //get details
    public void getDetails(){

        System.out.println("Enter your name:");
        name=sc.nextLine();
        System.out.println("Enter your age:");
        age=sc.nextInt();
        System.out.println("Enter your weapon:");
        weapon=sc.nextLine();
        sc.nextLine();
        System.out.println("Enter your power:");
        power=sc.nextLine();
        //sc.nextLine();
        System.out.println("Enter your planet:");
        planet=sc.nextLine();
    }
        //print details
    public void displayDetails(){
        System.out.println("The name is "+name+" , the age is "+age+" ,the power is "+power+" ,the weapon is "+weapon+" and the planet is "+planet);
    }

    public static void main(String args[]){
         
        avenger[] avg=new avenger[5];
        for(int i=0;i<5;i++){
            avg[i]=new avenger();
            avg[i].getDetails();
        }
        for(int i=0;i<5;i++)
        {
            avg[i].displayDetails();
        }
    }
 }