import java.util.Scanner;

public class array{

    public static void main(String args[]){
        int result=0;
        Scanner sc=new Scanner(System.in);
        int[] numbers=new int[5];
        for(int i=0;i<5;i++)
       {
          System.out.println("Enter a number:");
           numbers[i]=sc.nextInt();
       }

       for(int i=0;i<5;i++)
       {
           result=result+numbers[i];
       }
       System.out.println("The sum is: "+result);

    }

}